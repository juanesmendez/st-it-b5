package uniandes.isis2304.superandes.negocio;

public interface VOCategoria {

	String getNombre();

	long getId();

	@Override
	String toString();
}
