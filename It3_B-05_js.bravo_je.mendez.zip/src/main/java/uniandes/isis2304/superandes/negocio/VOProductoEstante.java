package uniandes.isis2304.superandes.negocio;

public interface VOProductoEstante {

	int getCantidad();

	long getIdEstante();

	long getIdProducto();

}
