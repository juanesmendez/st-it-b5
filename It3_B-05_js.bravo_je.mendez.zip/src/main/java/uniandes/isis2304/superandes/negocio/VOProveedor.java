package uniandes.isis2304.superandes.negocio;

public interface VOProveedor {

	String getNombre();

	long getNit();

	long getId();
	
	@Override
	String toString();
}
