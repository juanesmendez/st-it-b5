package uniandes.isis2304.superandes.negocio;

public class CategoriaSucursal implements VOCategoriaSucursal {

}
