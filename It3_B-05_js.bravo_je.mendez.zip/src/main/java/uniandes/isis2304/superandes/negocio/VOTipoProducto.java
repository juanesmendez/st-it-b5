package uniandes.isis2304.superandes.negocio;

public interface VOTipoProducto {

	long getIdCategoria();

	String getNombre();

	long getId();
	
	@Override
	String toString();
}
