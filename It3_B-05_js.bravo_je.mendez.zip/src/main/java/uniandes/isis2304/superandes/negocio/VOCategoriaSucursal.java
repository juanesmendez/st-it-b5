package uniandes.isis2304.superandes.negocio;

public interface VOCategoriaSucursal {

}
