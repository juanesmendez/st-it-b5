package uniandes.isis2304.superandes.negocio;

public interface VOCliente {

	int getPuntos();

	String getDireccion();

	String getCorreo();

	String getNombre();

	String getTipo();

	long getIdentificacion();

}
