package uniandes.isis2304.superandes.negocio;

public interface VOVendeCarrito {
    long getIdCarrito();
    long getIdProducto();
    int getCantidadCarrito();
}
