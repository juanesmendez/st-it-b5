package uniandes.isis2304.superandes.negocio;

public interface VOProductoCarrito {
    long getIdProducto();
    long getIdCarrito();
}
