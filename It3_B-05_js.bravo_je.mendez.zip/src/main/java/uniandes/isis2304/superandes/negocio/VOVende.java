package uniandes.isis2304.superandes.negocio;

public interface VOVende {

	int getCantRecompra();

	int getNivReorden();

	double getPrecioUniMedida();

	double getPrecio();

	long getIdProducto();

	long getIdSucursal();
	
}
