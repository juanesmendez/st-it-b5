package uniandes.isis2304.superandes.negocio;

public interface VOFacturaProducto {

	int getUniVendidas();

	long getIdProducto();

	long getIdFactura();

}
