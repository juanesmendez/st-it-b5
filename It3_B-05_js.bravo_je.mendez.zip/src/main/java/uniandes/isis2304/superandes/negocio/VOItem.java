package uniandes.isis2304.superandes.negocio;

public interface VOItem {

	long getIdProducto();

	String getNombre();

	int getCantidad();

	double getPrecio();

	double getSubTotal();

}