package uniandes.isis2304.superandes.negocio;

public interface VOProvee {

	long getIdProducto();

	long getIdProveedor();

}
