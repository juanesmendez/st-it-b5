package uniandes.isis2304.superandes.negocio;

public interface VOBodega {

	double getPeso();

	double getVolumen();

	long getIdSucursal();

	long getId();

	long getIdTipoproducto();

}
