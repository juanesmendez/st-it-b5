package uniandes.isis2304.superandes.negocio;

public interface VOProductoBodega {

	int getCantidad();

	long getIdBodega();

	long getIdProducto();

}
