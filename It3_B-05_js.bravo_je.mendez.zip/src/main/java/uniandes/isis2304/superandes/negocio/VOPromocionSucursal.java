package uniandes.isis2304.superandes.negocio;

public interface VOPromocionSucursal {
    long getIdPromocion();
    long getIdSucursal();

}
