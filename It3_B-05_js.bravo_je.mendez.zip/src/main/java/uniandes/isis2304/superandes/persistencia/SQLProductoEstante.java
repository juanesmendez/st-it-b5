package uniandes.isis2304.superandes.persistencia;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

public class SQLProductoEstante {
	/* ****************************************************************
	 * 			Constantes
	 *****************************************************************/
	/**
	 * Cadena que representa el tipo de consulta que se va a realizar en las sentencias de acceso a la base de datos
	 * Se renombra acá para facilitar la escritura de las sentencias
	 */
	private final static String SQL = PersistenciaSuperandes.SQL;

	/* ****************************************************************
	 * 			Atributos
	 *****************************************************************/
	/**
	 * El manejador de persistencia general de la aplicación
	 */
	private PersistenciaSuperandes ps;

	/* ****************************************************************
	 * 			Métodos
	 *****************************************************************/

	/**
	 * Constructor
	 * @param pp - El Manejador de persistencia de la aplicación
	 */
	public SQLProductoEstante (PersistenciaSuperandes ps)
	{
		this.ps = ps;
	}

	public long actualizarCantidad(PersistenceManager pm, long idSucursal, long idProducto, long numUnidades) {
		// TODO Auto-generated method stub
		String sql = "UPDATE (SELECT " + ps.darTablaEstantes() + ".id, " + ps.darTablaEstantes() + ".idSucursal, " + ps.darTablaProductoEstante() + ".idProducto, " + ps.darTablaProductoEstante() + ".cantidad ";
		sql +=  "FROM " + ps.darTablaEstantes() + " ";
		sql += "INNER JOIN " + ps.darTablaProductoEstante() + " ON " + ps.darTablaEstantes() + ".id = " + ps.darTablaProductoEstante() + ".idEstante ";
		sql += "WHERE " + ps.darTablaEstantes() + ".idSucursal = ? AND  " + ps.darTablaProductoEstante() + ".idProducto = ? ) T ";
		sql += "SET T.CANTIDAD = T.CANTIDAD - ?";
		Query q = pm.newQuery(SQL, sql);
		/*
		Map<String,Long> params = new HashMap();
		params.put("idsucursal", idSucursal);
		params.put("idproducto", idProducto);
		params.put("cantidad", numUnidades);
		q.setNamedParameters(params);
		*/
		q.setParameters(idSucursal,idProducto,numUnidades);
		
		return (long)q.executeUnique();
	}

	public long actualizarCantidadEstantePorCarrito(PersistenceManager pm, long idEstante, long idProducto, int cantidad) {

        Query q = pm.newQuery(SQL, "UPDATE " + ps.darTablaProductoEstante () + " SET  cantidad = ? where idEstante = ? AND idProducto = ? ");
        q.setParameters(cantidad, idEstante, idProducto);
        return (long) q.executeUnique();
	}
	
	public int darCantidadProducto(PersistenceManager pm, long idEstante, long idProducto)
	{
		  Query q = pm.newQuery(SQL, "SELECT cantidad FROM " + ps.darTablaProductoEstante () + " where idEstante = ? AND idProducto = ? ");
	        q.setParameters(idEstante, idProducto);
	        return ((BigDecimal) q.executeUnique()).intValue();
	        
	}
}
