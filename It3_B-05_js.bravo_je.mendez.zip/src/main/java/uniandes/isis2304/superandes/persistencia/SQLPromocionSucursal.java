package uniandes.isis2304.superandes.persistencia;

public class SQLPromocionSucursal {

    //TODO
}
